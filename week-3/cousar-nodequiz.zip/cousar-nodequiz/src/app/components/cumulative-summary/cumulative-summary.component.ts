/*
============================================
; Title: NodeQuiz
; Author: Don Cousar
; Date: 29 September 2019
; Description: MEAN Stack Node Quiz Project
;===========================================
*/
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cumulative-summary',
  template: `
    <p>
      cumulative-summary works!
    </p>
  `,
  styles: []
})
export class CumulativeSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
